kicad-library
=============

A library of KiCad components and footprints managed by the geekhack.org community.

This project aims to create a set of KiCad libraries and modules of electronic components which might be useful in computer keyboard design.
The components in this repository should be tested and volume-production ready to allow us to design and produce new ideas quickly and easily.
